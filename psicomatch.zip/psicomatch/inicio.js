// inicio.js - Funcionalidad de la landing page

document.addEventListener("DOMContentLoaded", () => {
  // ===============================
  // SCROLL SUAVE EN LINKS DEL NAV
  // ===============================
  const navLinks = document.querySelectorAll("nav a[href^='#']");
  navLinks.forEach(link => {
    link.addEventListener("click", (e) => {
      e.preventDefault();
      const targetId = link.getAttribute("href");
      const targetElement = document.querySelector(targetId);
      if (targetElement) {
        window.scrollTo({
          top: targetElement.offsetTop - 60,
          behavior: "smooth"
        });
      }
    });
  });

  // ===============================
  // BOTÓN "BUSCAR PSICÓLOGOS"
  // ===============================
  const buscarBtn = document.querySelector(".hero button");
  if (buscarBtn) {
    buscarBtn.addEventListener("click", () => {
      const testimonios = document.querySelector(".testimonials");
      if (testimonios) {
        testimonios.scrollIntoView({ behavior: "smooth" });
      }
    });
  }

  // ===============================
  // CARRUSEL DE TESTIMONIOS
  // ===============================
  const testimonios = document.querySelectorAll(".testimonial");
  let index = 0;

  function showTestimonial(i) {
    testimonios.forEach((t, idx) => {
      t.style.display = idx === i ? "block" : "none";
    });
  }

  if (testimonios.length > 0) {
    showTestimonial(index);
    setInterval(() => {
      index = (index + 1) % testimonios.length;
      showTestimonial(index);
    }, 4000); // cambia cada 4s
  }

  // ===============================
  // BOTÓN VOLVER ARRIBA
  // ===============================
  const backToTop = document.createElement("button");
  backToTop.innerText = "⬆";
  backToTop.id = "back-to-top";
  document.body.appendChild(backToTop);

  backToTop.style.position = "fixed";
  backToTop.style.bottom = "20px";
  backToTop.style.right = "20px";
  backToTop.style.display = "none";
  backToTop.style.padding = "10px 15px";
  backToTop.style.fontSize = "18px";
  backToTop.style.border = "none";
  backToTop.style.borderRadius = "50%";
  backToTop.style.cursor = "pointer";
  backToTop.style.background = "#6c63ff";
  backToTop.style.color = "#fff";
  backToTop.style.boxShadow = "0px 4px 6px rgba(0,0,0,0.2)";

  window.addEventListener("scroll", () => {
    if (window.scrollY > 200) {
      backToTop.style.display = "block";
    } else {
      backToTop.style.display = "none";
    }
  });

  backToTop.addEventListener("click", () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  });
});
