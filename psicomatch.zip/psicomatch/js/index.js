const openBtn = document.getElementById("openFilterBtn");
const overlay = document.getElementById("filterOverlay");
const modal = document.getElementById("filterModal");
const closeBtn = document.getElementById("closeFilterBtn");
const clearBtn = document.getElementById("clearFilters");

// Abrir modal
openBtn.addEventListener("click", () => {
  overlay.style.display = "block";
  modal.style.display = "block";
  setTimeout(() => modal.style.transform = "translate(-50%, -50%) scale(1)", 10);
});

// Cerrar modal
function closeModal() {
  modal.style.transform = "translate(-50%, -50%) scale(0.8)";
  setTimeout(() => {
    overlay.style.display = "none";
    modal.style.display = "none";
  }, 150);
}

closeBtn.addEventListener("click", closeModal);
overlay.addEventListener("click", closeModal);

// Selección de tipo de psicólogo
document.querySelectorAll(".type-box").forEach(box => {
  box.addEventListener("click", () => {
    document.querySelectorAll(".type-box").forEach(b => b.classList.remove("selected"));
    box.classList.add("selected");
  });
});

// Botón limpiar
clearBtn.addEventListener("click", () => {
  document.querySelectorAll("input[type='checkbox']").forEach(ch => ch.checked = false);
  document.querySelectorAll("input[type='number']").forEach(n => n.value = "");
  document.getElementById("minPriceInput").value = "$20.0";
  document.getElementById("maxPriceInput").value = "$500";
});
