document.addEventListener("DOMContentLoaded", () => {
  // ===============================
  // PROTECCIÓN DE RUTA - Verificar sesión
  // ===============================
  const userSession = localStorage.getItem('userSession');
  if (!userSession) {
    // Si no hay sesión activa, redirigir a login
    window.location.href = 'login.html';
    return;
  }

  // ===============================
  // CERRAR SESIÓN
  // ===============================
  const logoutBtn = document.getElementById('logout-btn-acerca');
  if (logoutBtn) {
    logoutBtn.addEventListener('click', (e) => {
      e.preventDefault();
      localStorage.removeItem('userSession');
      window.location.href = 'login.html';
    });
  }

  // Animación suave al hacer scroll
  const sections = document.querySelectorAll(".mision, .vision, .valor-card, .equipo-card");

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add("visible");
      }
    });
  }, { threshold: 0.2 });

  sections.forEach(sec => observer.observe(sec));

  // Efecto de aparición
  const style = document.createElement("style");
  style.textContent = `
    .mision, .vision, .valor-card, .equipo-card {
      opacity: 0;
      transform: translateY(30px);
      transition: all 0.6s ease;
    }
    .visible {
      opacity: 1;
      transform: translateY(0);
    }
  `;
  document.head.appendChild(style);
});
