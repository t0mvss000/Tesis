document.addEventListener("DOMContentLoaded", () => {
  // Animación suave al hacer scroll
  const sections = document.querySelectorAll(".mision, .vision, .valor-card, .equipo-card");

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add("visible");
      }
    });
  }, { threshold: 0.2 });

  sections.forEach(sec => observer.observe(sec));

  // Efecto de aparición
  const style = document.createElement("style");
  style.textContent = `
    .mision, .vision, .valor-card, .equipo-card {
      opacity: 0;
      transform: translateY(30px);
      transition: all 0.6s ease;
    }
    .visible {
      opacity: 1;
      transform: translateY(0);
    }
  `;
  document.head.appendChild(style);
});
