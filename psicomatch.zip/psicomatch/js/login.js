document.getElementById('login-form').addEventListener('submit', async function(event) {
  event.preventDefault();

  const email = document.getElementById('email').value.trim();
  const password = document.getElementById('password').value.trim();

  if (!email || !password) {
    alert('Por favor ingresa tu correo y contraseña.');
    return;
  }

  try {
    const response = await fetch('http://localhost:3000/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password })
    });

    const data = await response.json();

    if (response.ok) {
      alert(data.message);
      window.location.href = 'landing.html';
    } else {
      alert(data.message || 'No se pudo iniciar sesión.');
    }
  } catch (error) {
    alert('Error de conexión con el servidor.');
    console.error('Error al iniciar sesión:', error);
  }
});
