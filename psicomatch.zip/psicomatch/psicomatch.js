// ===============================
// FILTROS DE PSICÓLOGOS
// ===============================
const filterButtons = document.querySelectorAll(".filters button");
const cards = document.querySelectorAll(".card");

filterButtons.forEach(button => {
  button.addEventListener("click", () => {
    const filter = button.getAttribute("data-filter");

    cards.forEach(card => {
      if (filter === "all" || card.classList.contains(filter)) {
        card.style.display = "block";
      } else {
        card.style.display = "none";
      }
    });
  });
});

// ===============================
// BOTÓN "VER MÁS"
// ===============================
const moreBtn = document.querySelector(".more-btn");
if (moreBtn) {
  moreBtn.addEventListener("click", () => {
    alert("Aquí puedes cargar más psicólogos desde el servidor 🔄");
    // Ejemplo real sería hacer fetch() a la API y agregar más tarjetas dinámicamente
  });
}

// ===============================
// MODAL DE CONTACTO
// ===============================
const contactButtons = document.querySelectorAll(".btn-contactar");
const modal = document.querySelector("#contact-modal");
const modalClose = document.querySelector("#close-modal");

contactButtons.forEach(btn => {
  btn.addEventListener("click", () => {
    if (modal) modal.style.display = "flex"; // muestra modal
  });
});

if (modalClose) {
  modalClose.addEventListener("click", () => {
    if (modal) modal.style.display = "none"; // cierra modal
  });
}

// Cerrar modal al hacer click fuera
window.addEventListener("click", (e) => {
  if (modal && e.target === modal) {
    modal.style.display = "none";
  }
});

// Manejar envío simple del formulario (mock)
const contactForm = document.querySelector("#contact-form");
if (contactForm) {
  contactForm.addEventListener("submit", (e) => {
    e.preventDefault();
    // recoger datos si hace falta
    alert("Mensaje enviado (simulado). Gracias.");
    if (modal) modal.style.display = "none";
    contactForm.reset();
  });
}
